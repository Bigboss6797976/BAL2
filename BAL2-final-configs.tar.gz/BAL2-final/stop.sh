#!/bin/bash
# BAL2 - 停止所有服务

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}🛑 停止 BAL2 服务...${NC}"

# 停止 tmux 会话
if tmux has-session -t bal2 2>/dev/null; then
    tmux kill-session -t bal2
    echo -e "${GREEN}✅ tmux 会话已停止${NC}"
fi

# 停止后台进程
if [ -f .pids ]; then
    PIDS=$(cat .pids)
    kill $PIDS 2>/dev/null || true
    rm .pids
    echo -e "${GREEN}✅ 后台进程已停止${NC}"
fi

# 查找并停止相关进程
pkill -f "hardhat node" 2>/dev/null || true
pkill -f "node server.js" 2>/dev/null || true
pkill -f "react-scripts start" 2>/dev/null || true

echo -e "${GREEN}✅ 所有服务已停止${NC}"
