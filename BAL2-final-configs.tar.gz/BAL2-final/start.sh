#!/bin/bash
# BAL2 - 一键启动所有服务

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${GREEN}🚀 BAL2 - 启动所有服务${NC}"

# 创建日志目录
mkdir -p logs

# 检查 tmux
if command -v tmux &> /dev/null; then
    echo -e "${BLUE}使用 tmux 启动...${NC}"

    # 如果已有会话，先杀掉
    tmux kill-session -t bal2 2>/dev/null || true

    # 创建新会话
    tmux new-session -d -s bal2 -n 'node'
    tmux send-keys -t bal2:0 'echo "[1/4] 启动 Hardhat 节点..." && npx hardhat node 2>&1 | tee logs/node.log' C-m

    tmux new-window -t bal2 -n 'deploy'
    tmux send-keys -t bal2:1 'sleep 6 && echo "[2/4] 部署合约..." && npx hardhat run scripts/deploy-all.js --network hardhat 2>&1 | tee logs/deploy.log' C-m

    tmux new-window -t bal2 -n 'signer'
    tmux send-keys -t bal2:2 'sleep 10 && echo "[3/4] 启动离线签名服务..." && cd offline-signer && SIGNER_KEY=0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d node server.js 2>&1 | tee ../logs/signer.log' C-m

    tmux new-window -t bal2 -n 'frontend'
    tmux send-keys -t bal2:3 'sleep 12 && echo "[4/4] 启动前端..." && npm run dev 2>&1 | tee logs/frontend.log' C-m

    echo ""
    echo -e "${GREEN}✅ 所有服务已在 tmux 会话中启动！${NC}"
    echo ""
    echo -e "${BLUE}tmux 命令:${NC}"
    echo "  连接会话: tmux attach -t bal2"
    echo "  切换窗口: Ctrl+B 然后按 0-3"
    echo "  分离会话: Ctrl+B 然后按 D"
    echo "  查看列表: tmux ls"
    echo ""
    echo -e "${YELLOW}是否现在连接 tmux 会话? (y/n)${NC}"
    read -r answer
    if [ "$answer" = "y" ] || [ "$answer" = "Y" ]; then
        tmux attach -t bal2
    fi

else
    echo -e "${YELLOW}未检测到 tmux，使用后台进程启动...${NC}"

    echo "[1/4] 启动 Hardhat 节点..."
    npx hardhat node > logs/node.log 2>&1 &
    NODE_PID=$!
    echo "  PID: $NODE_PID"

    sleep 6
    echo "[2/4] 部署合约..."
    npx hardhat run scripts/deploy-all.js --network hardhat > logs/deploy.log 2>&1 &
    DEPLOY_PID=$!
    echo "  PID: $DEPLOY_PID"

    sleep 4
    echo "[3/4] 启动离线签名服务..."
    cd offline-signer
    SIGNER_KEY=0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d node server.js > ../logs/signer.log 2>&1 &
    SIGNER_PID=$!
    cd ..
    echo "  PID: $SIGNER_PID"

    sleep 2
    echo "[4/4] 启动前端..."
    npm run dev > logs/frontend.log 2>&1 &
    DEV_PID=$!
    echo "  PID: $DEV_PID"

    echo ""
    echo -e "${GREEN}✅ 所有服务已后台启动！${NC}"
    echo ""
    echo "日志文件:"
    echo "  tail -f logs/node.log"
    echo "  tail -f logs/deploy.log"
    echo "  tail -f logs/signer.log"
    echo "  tail -f logs/frontend.log"
    echo ""
    echo "停止所有: kill $NODE_PID $DEPLOY_PID $SIGNER_PID $DEV_PID"

    # 保存 PID
    echo "$NODE_PID $DEPLOY_PID $SIGNER_PID $DEV_PID" > .pids
fi
