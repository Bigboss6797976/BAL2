# 🕵️ BAL2 - 区块链攻击实验室

[![CI/CD](https://github.com/Bigboss6797976/BAL2/actions/workflows/deploy.yml/badge.svg)](https://github.com/Bigboss6797976/BAL2/actions/workflows/deploy.yml)
[![GitHub Pages](https://img.shields.io/badge/GitHub%20Pages-Live-brightgreen)](https://bigboss6797976.github.io/BAL2)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

> ⚠️ **警告**: 本项目仅用于安全研究和教育目的，请勿用于非法活动。
> 
> **GitHub**: https://github.com/Bigboss6797976/BAL2
> **在线演示**: https://bigboss6797976.github.io/BAL2

## 🚀 一键安装

### 方式1: GitHub 克隆安装（推荐）

```bash
git clone https://github.com/Bigboss6797976/BAL2.git
cd BAL2
bash install.sh
```

### 方式2: Termux 安装

```bash
pkg install git nodejs

git clone https://github.com/Bigboss6797976/BAL2.git
cd BAL2
bash install.sh
```

## 🎮 启动项目

### 方式1: 一键启动（推荐）

```bash
bash start.sh
```

### 方式2: 手动启动（开4个终端窗口）

```bash
# 窗口1: 启动本地区块链节点
npx hardhat node

# 窗口2: 编译并部署合约
npx hardhat compile
npx hardhat run scripts/deploy-all.js --network hardhat

# 窗口3: 启动离线签名服务
cd offline-signer
SIGNER_KEY=0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d node server.js

# 窗口4: 启动前端开发服务器
npm run dev
```

### 方式3: npm 脚本启动

```bash
npm run start-all
```

## 🛑 停止服务

```bash
bash stop.sh
```

## 📦 功能特性

### 🔍 扫码转账
- 支持多种 QR 码格式（纯地址、EIP-681、JSON、BIP21）
- 自动解析收款地址和金额
- 实时查询 USDT 余额和授权额度

### 🔒 离线签名
- 私钥保存在隔离服务器，不触网
- 通过 API 请求 EIP-712 结构化签名
- 前端提交签名到链上执行

### 🕶️ 盲签攻击测试
- 盲化交易内容，隐藏真实转账信息
- 签名者无法知道实际签名内容
- **攻击面**: 用户无法验证实际交易金额和地址

### 💣 批量盲签攻击
- 一次请求多笔隐藏交易的签名
- 批量提交执行
- **攻击面**: 用户可能不知情地授权多笔转账

## 🏗️ 项目结构

```
BAL2/
├── .github/
│   └── workflows/
│       ├── deploy.yml              # CI/CD 自动构建部署
├── contracts/
│   ├── BlindQRTransfer.sol         # 主合约（离线签名+盲签+批量盲签）
│   ├── QRTransfer.sol              # 基础扫码合约
│   └── USDTMock.sol                # 测试用 USDT
├── offline-signer/
│   ├── server.js                   # 隔离签名服务
│   └── package.json
├── scripts/
│   └── deploy-all.js               # 一键部署脚本
├── src/
│   ├── components/
│   │   ├── AdvancedQRTransfer.tsx  # 主界面
│   │   └── AdvancedQRTransfer.css  # 暗黑科技风样式
│   ├── utils/
│   │   ├── qr-parser.ts            # QR码解析
│   │   ├── blind-signature.ts      # 盲签工具
│   │   └── constants.ts            # 合约地址（自动生成）
│   ├── abis/
│   │   ├── BlindQRTransfer.json
│   │   └── USDT.json
│   ├── App.tsx
│   └── index.tsx
├── test/
│   └── BlindQRTransfer.test.js     # 测试用例
├── hardhat.config.js               # Hardhat 配置
├── package.json                    # 依赖配置
├── install.sh                      # 一键安装脚本 ⭐
├── start.sh                        # 一键启动脚本 ⭐
├── stop.sh                         # 一键停止脚本 ⭐
└── README.md
```

## 🌐 四种转账模式

| 模式 | 私钥位置 | 用户可见性 | 安全风险 |
|------|----------|-----------|----------|
| **普通转账** | MetaMask | 完全可见 | 标准流程 |
| **离线签名** | 隔离服务器 | 完全可见 | API 可能被劫持 |
| **盲签** | 隔离服务器 | **完全不可见** | 用户无法验证交易内容 |
| **批量盲签** | 隔离服务器 | **完全不可见** | 多笔隐藏交易同时执行 |

## 🧪 攻击测试场景

### 场景1: 盲签金额篡改
```
前端显示: 转账 1 USDT 给 Alice
实际盲签: 转账 1000 USDT 给 Attacker
结果: 用户损失 1000 USDT
```

### 场景2: 批量盲签钓鱼
```
用户以为只签1笔，实际签了3笔:
- 100 USDT 给 Attacker_1
- 200 USDT 给 Attacker_2
- 300 USDT 给 Attacker_3
```

## 🔧 技术栈

- **合约**: Solidity 0.8.19 + OpenZeppelin
- **前端**: React 18 + TypeScript + Ethers.js v6
- **后端**: Node.js + Express + Ethers.js
- **测试**: Hardhat + Anvil
- **CI/CD**: GitHub Actions

## 🚀 GitHub Pages 部署

本项目配置自动部署到 GitHub Pages：

1. 在仓库 Settings -> Pages -> Source 选择 **"GitHub Actions"**
2. 推送代码到 `main` 分支
3. GitHub Actions 自动构建并部署
4. 访问 https://bigboss6797976.github.io/BAL2

## 📝 环境变量

复制 `.env.example` 为 `.env` 并配置：

```bash
# 私钥配置（仅用于测试！）
PRIVATE_KEY=0x...

# 离线签名服务私钥
SIGNER_KEY=0x...

# API Keys（可选）
ETHERSCAN_API_KEY=...
ALCHEMY_API_KEY=...
```

## 🤝 贡献

欢迎提交 Issue 和 PR！

## 📄 License

Apache-2.0 - 仅用于教育和安全研究目的。
